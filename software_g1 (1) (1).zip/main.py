from db import get_connection

def run_inventory_report():
    conn = get_connection()
    cursor = conn.cursor()

    inventory_sql = """
    SELECT
        m.material_id,
        m.name AS material_name,
        SUM(s.qty_on_hand) AS total_on_hand,
        m.min_level,
        m.max_level,
        CASE 
            WHEN SUM(s.qty_on_hand) < m.min_level THEN 1 
            ELSE 0 
        END AS is_below_min
    FROM material m
    JOIN stock s ON s.material_id = m.material_id
    GROUP BY
        m.material_id, m.name, m.min_level, m.max_level
    ORDER BY m.material_id;
    """

    cursor.execute(inventory_sql)

    print("INVENTORY HEALTH REPORT")
    print("-----------------------")
    for row in cursor.fetchall():
        print(row)

    cursor.close()
    conn.close()

if __name__ == "__main__":
    run_inventory_report()
