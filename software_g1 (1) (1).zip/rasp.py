import time
import mysql.connector
from mysql.connector import Error
import RPi.GPIO as GPIO


DB_CONFIG = {
    "host": "10.209.55.95",
    "user": "crame2aj",
    "password": "F$up^caQP*7ZLB",
    "database": "bis425_g1",
}


def get_connection():
    
    return mysql.connector.connect(**DB_CONFIG)



def log_bin_removed(sensor_id, workcenter_id, material_id, qty_issued):


    conn = None
    cursor = None

    try:
        conn = get_connection()
        cursor = conn.cursor()

        print("\n[STEP] Connected. Processing bin removal...")
        print(
            f"[INFO] sensor_id={sensor_id}, workcenter_id={workcenter_id}, "
            f"material_id={material_id}, qty_issued={qty_issued}"
        )

       
        cursor.execute(
            """
            INSERT INTO sensorevent (
                sensor_id,
                event_ts,
                reading_value,
                triggered
            )
            VALUES (%s, NOW(), %s, %s)
            """,
            (sensor_id, 1, 1),
        )
        print("[STEP] Logged sensor event -> sensorevent.")

        
        cursor.execute(
            """
            INSERT INTO materialtrans (
                trans_ts,
                workcenter_id_from,
                workcenter_id_to,
                material_id,
                qty,
                trans_type,
                reference
            )
            VALUES (NOW(), %s, %s, %s, %s, 'issue', %s)
            """,
            (7, workcenter_id, material_id, qty_issued, "WO-9001"),
        )
        print("[STEP] Logged material issue -> materialtrans.")

      
        cursor.execute(
            """
            UPDATE stock
            SET qty_on_hand   = qty_on_hand - %s,
                last_counted_at = NOW()
            WHERE workcenter_id = %s
              AND material_id   = %s
            """,
            (qty_issued, workcenter_id, material_id),
        )
        print("[STEP] Updated stock -> stock table.")

       
        cursor.execute(
            """
            SELECT qty_on_hand
            FROM stock
            WHERE workcenter_id = %s
              AND material_id   = %s
            """,
            (workcenter_id, material_id),
        )
        result = cursor.fetchone()

        if not result:
            print("[WARN] No stock row found for this workcenter/material.")
            qty_left = None
        else:
            (qty_left,) = result
            print(
                f"[INFO] New stock level at WC {workcenter_id} "
                f"for material {material_id} = {qty_left}"
            )

        
        THRESHOLD = 300  # adjust as needed
        print(f"[DEBUG] qty_left={qty_left}, threshold={THRESHOLD}")

        if qty_left is not None and qty_left <= THRESHOLD:
            print(
                "[ALERT] Stock below threshold. "
                "Creating replenishment request, line, and task..."
            )

       
            cursor.execute(
                """
                INSERT INTO replenishmentrequest (
                    workcenter_id,
                    requested_by,
                    request_ts,
                    status,
                    priority
                )
                VALUES (%s, %s, NOW(), 'Open', 'High')
                """,
                (workcenter_id, 1),
            )
            req_id = cursor.lastrowid

            
            cursor.execute(
                """
                INSERT INTO replenishmentline (
                    req_id,
                    material_id,
                    qty_requested,
                    qty_fulfilled
                )
                VALUES (%s, %s, %s, 0)
                """,
                (req_id, material_id, 50),  # 50 = example qty
            )
            print(
                f"[OK] Created replenishment request #{req_id} "
                "and replenishment line."
            )

          
           
            cursor.execute(
                """
                INSERT INTO replenishmenttask (
                    req_id,
                    assigned_to,
                    task_ts,
                    status,
                    workcenter_from,
                    workcenter_to
                )
                VALUES (%s, %s, NOW(), 'Queued', %s, %s)
                """,
                (req_id, 1, 7, workcenter_id),
            )
            print("[OK] Created replenishment task for request.")
        else:
            print(
                "[INFO] Stock not below threshold; "
                "no replenishment request created."
            )

        
        conn.commit()
        print("[DONE] log_bin_removed completed and committed.\n")

    except Error as e:
        print(f"[DB ERROR] {e}")
        if conn:
            conn.rollback()
            print("[INFO] Transaction rolled back due to error.")
    finally:
        if cursor is not None:
            cursor.close()
        if conn is not None:
            conn.close()



SENSOR_PINS = {
    1: 11,
    2: 13,
    3: 15,
}


BIN_MAPPING = {
    1: {"workcenter_id": 2, "material_id": 100},  
    2: {"workcenter_id": 2, "material_id": 100},  
    3: {"workcenter_id": 2, "material_id": 100},  
}


def make_sensor_callback(sensor_id):
    

    def callback(channel):
        print(f"\n[EVENT] Sensor {sensor_id} triggered on pin {channel}")

        mapping = BIN_MAPPING.get(sensor_id)
        if not mapping:
            print(f"[WARN] No BIN_MAPPING entry for sensor_id={sensor_id}")
            return

        workcenter_id = mapping["workcenter_id"]
        material_id = mapping["material_id"]

        
        log_bin_removed(
            sensor_id=sensor_id,
            workcenter_id=workcenter_id,
            material_id=material_id,
            qty_issued=1,
        )

    return callback


def setup_gpio():
    print("[PI] Setting up GPIO (BOARD mode)...")
    GPIO.setmode(GPIO.BOARD)

    for sensor_id, pin in SENSOR_PINS.items():
        GPIO.setup(pin, GPIO.IN, pull_up_down=GPIO.PUD_UP)

        
        GPIO.add_event_detect(
            pin,
            GPIO.FALLING,
            callback=make_sensor_callback(sensor_id),
            bouncetime=300,
        )

    print("[PI] GPIO setup complete. Waiting for sensor events...")


if __name__ == "__main__":
    try:
        setup_gpio()
        print("[PI] Press Ctrl+C to stop.\n")

        # Keep the script running so callbacks can fire
        while True:
            time.sleep(0.1)

    except KeyboardInterrupt:
        print("\n[PI] Stopping program...")

    finally:
        GPIO.cleanup()
        print("[PI] GPIO cleaned up.")