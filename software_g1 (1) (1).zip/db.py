# db.py  (inside BIS_425/py)

import mysql.connector

def get_connection():
    """Create and return a new MySQL connection."""
    return mysql.connector.connect(
        host="10.209.55.95",          # DB server
        user="tooke1te",              # username
        password="InitPass!",    # password
        database="bis425_g1"          # schema
    )

#  test if run this file directly
if __name__ == "__main__":
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT NOW();")
    print("DB time:", cursor.fetchone())
    cursor.close()
    conn.close()
