# BIS 425 Flask Setup

from flask import (
    Flask,
    render_template,
    request,
    redirect,
    url_for,
    session,
    flash,
)
import mysql.connector
from functools import wraps

app = Flask(__name__)

# ========= FLASK CONFIG =========

app.secret_key = "bis425_g1"

# ========= DATABASE CONFIG =========
DB_CONFIG = {
    "host": "10.209.55.95",
    "user": "tooke1te",
    "password": "InitPass!",
    "database": "bis425_g1",
}

def get_connection():
    """Open a new MySQL connection using DB_CONFIG."""
    return mysql.connector.connect(**DB_CONFIG)


# ========= SIMPLE AUTH CONFIG =========
VALID_USERNAME = "admin"
VALID_PASSWORD = "password123"


def login_required(view_func):
    """Decorator requiring login."""
    @wraps(view_func)
    def wrapped_view(*args, **kwargs):
        if "user" not in session:
            return redirect(url_for("login"))
        return view_func(*args, **kwargs)
    return wrapped_view


# ========= ROUTES =========

@app.route("/login", methods=["GET", "POST"])
def login():
    """Login page."""
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "").strip()

        if username == VALID_USERNAME and password == VALID_PASSWORD:
            session["user"] = username
            flash("Logged in successfully.", "success")
            return redirect(url_for("home"))
        else:
            flash("Invalid username or password.", "danger")

    return render_template("login.html")


@app.route("/logout")
def logout():
    """Clear session."""
    session.pop("user", None)
    flash("You have been logged out.", "info")
    return redirect(url_for("login"))


@app.route("/")
@login_required
def home():
    """Dashboard home."""
    return render_template("home.html")


# ================================================================
#  INVENTORY REPORT (CLEAN VERSION — NO QTY MOVED)
# ================================================================
@app.route("/inventory")
@login_required
def inventory_report():
    """
    Full inventory report for all materials.
    Shows workcenter and current quantity only.
    """
    con = get_connection()
    cur = con.cursor(dictionary=True)

    query = """
        SELECT 
            m.material_id,
            m.name,
            m.min_level,

            -- Correct workcenter for each material
            COALESCE((
                SELECT workcenter_id
                FROM stock 
                WHERE stock.material_id = m.material_id
                ORDER BY qty_on_hand DESC
                LIMIT 1
            ), 0) AS workcenter_id,

            -- Current quantity from actual WC
            COALESCE((
                SELECT qty_on_hand
                FROM stock 
                WHERE stock.material_id = m.material_id
                ORDER BY qty_on_hand DESC
                LIMIT 1
            ), 0) AS current_qty

        FROM material m
        ORDER BY m.material_id;
    """

    cur.execute(query)
    materials = cur.fetchall()

    cur.close()
    con.close()

    return render_template("inventory.html", materials=materials)


# ================================================================
#  REPLENISHMENT REPORT (ADDS WORKCENTER)
# ================================================================
@app.route("/replenish")
@login_required
def replenish_report():
    """
    Shows only materials where current_qty < min_level.
    Adds workcenter so replenishment knows where to go.
    """
    con = get_connection()
    cur = con.cursor(dictionary=True)

    query = """
        SELECT 
            m.material_id,
            m.name,
            m.min_level,

            -- Identify the correct workcenter
            COALESCE((
                SELECT workcenter_id
                FROM stock 
                WHERE stock.material_id = m.material_id
                ORDER BY qty_on_hand DESC
                LIMIT 1
            ), 0) AS workcenter_id,

            -- Current quantity
            COALESCE((
                SELECT qty_on_hand
                FROM stock 
                WHERE stock.material_id = m.material_id
                ORDER BY qty_on_hand DESC
                LIMIT 1
            ), 0) AS current_qty

        FROM material m
        HAVING current_qty < m.min_level
        ORDER BY current_qty ASC;
    """

    cur.execute(query)
    materials = cur.fetchall()

    cur.close()
    con.close()

    return render_template("replenish.html", materials=materials)


# ========= MAIN =========
if __name__ == "__main__":
    app.run(debug=True)
